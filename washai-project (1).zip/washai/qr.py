"""
Minimal QR Code generator (no external libraries).
Supports byte mode, error-correction level M, versions 1-3 (up to 42 bytes).
That is plenty for WashAI codes such as "WA-35ED5FEA".

Usage:
    from qr import qr_svg
    svg = qr_svg("WA-35ED5FEA")
"""

# version -> (data codewords, ecc codewords, alignment-pattern centres)   [level M, single block]
_VERSIONS = {1: (16, 10, []), 2: (28, 16, [6, 18]), 3: (44, 26, [6, 22])}
_FORMAT_M = 0  # format bits for error-correction level M


def _gf_mul(x, y):
    z = 0
    for i in range(7, -1, -1):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _rs_divisor(degree):
    result = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(degree):
            result[j] = _gf_mul(result[j], root)
            if j + 1 < degree:
                result[j] ^= result[j + 1]
        root = _gf_mul(root, 2)
    return result


def _rs_remainder(data, divisor):
    result = [0] * len(divisor)
    for b in data:
        factor = b ^ result.pop(0)
        result.append(0)
        for i, coef in enumerate(divisor):
            result[i] ^= _gf_mul(coef, factor)
    return result


def _bit(value, i):
    return (value >> i) & 1 != 0


def make_matrix(text):
    """Return the QR matrix as a list of rows of booleans (True = dark)."""
    payload = text.encode("utf-8")
    version = None
    for v, (data_cw, _, _) in _VERSIONS.items():
        if 4 + 8 + 8 * len(payload) <= data_cw * 8:
            version = v
            break
    if version is None:
        raise ValueError("text too long for this minimal QR encoder (max 42 bytes)")
    data_cw, ecc_cw, align = _VERSIONS[version]
    size = version * 4 + 17

    # ---- bit stream ----
    bits = []
    def put(val, n):
        bits.extend(((val >> i) & 1) for i in range(n - 1, -1, -1))
    put(0b0100, 4)                # byte mode
    put(len(payload), 8)          # character count
    for b in payload:
        put(b, 8)
    put(0, min(4, data_cw * 8 - len(bits)))   # terminator
    put(0, (-len(bits)) % 8)                  # byte align
    pad = 0xEC
    while len(bits) < data_cw * 8:
        put(pad, 8)
        pad ^= 0xEC ^ 0x11
    data = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    codewords = data + _rs_remainder(data, _rs_divisor(ecc_cw))

    # ---- function patterns ----
    modules = [[False] * size for _ in range(size)]
    is_fn = [[False] * size for _ in range(size)]

    def set_fn(x, y, dark):
        modules[y][x] = dark
        is_fn[y][x] = True

    for i in range(size):
        set_fn(6, i, i % 2 == 0)
        set_fn(i, 6, i % 2 == 0)

    def finder(cx, cy):
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                dist = max(abs(dx), abs(dy))
                x, y = cx + dx, cy + dy
                if 0 <= x < size and 0 <= y < size:
                    set_fn(x, y, dist not in (2, 4))
    finder(3, 3); finder(size - 4, 3); finder(3, size - 4)

    for cy in align:
        for cx in align:
            if (cx, cy) in ((6, 6), (6, align[-1]), (align[-1], 6)):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    set_fn(cx + dx, cy + dy, max(abs(dx), abs(dy)) != 1)

    def draw_format(mask):
        d = (_FORMAT_M << 3) | mask
        rem = d
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        fb = ((d << 10) | rem) ^ 0x5412
        for i in range(0, 6):
            set_fn(8, i, _bit(fb, i))
        set_fn(8, 7, _bit(fb, 6)); set_fn(8, 8, _bit(fb, 7)); set_fn(7, 8, _bit(fb, 8))
        for i in range(9, 15):
            set_fn(14 - i, 8, _bit(fb, i))
        for i in range(8):
            set_fn(size - 1 - i, 8, _bit(fb, i))
        for i in range(8, 15):
            set_fn(8, size - 15 + i, _bit(fb, i))
        set_fn(8, size - 8, True)     # always-dark module
    draw_format(0)  # reserve the area

    # ---- place data (zig-zag) ----
    i = 0
    right = size - 1
    while right >= 1:
        if right == 6:
            right = 5
        for vert in range(size):
            for j in range(2):
                x = right - j
                upward = ((right + 1) & 2) == 0
                y = size - 1 - vert if upward else vert
                if not is_fn[y][x] and i < len(codewords) * 8:
                    modules[y][x] = _bit(codewords[i >> 3], 7 - (i & 7))
                    i += 1
        right -= 2

    # ---- masking ----
    def apply_mask(mask):
        for y in range(size):
            for x in range(size):
                m = [
                    (x + y) % 2 == 0, y % 2 == 0, x % 3 == 0, (x + y) % 3 == 0,
                    (x // 3 + y // 2) % 2 == 0, x * y % 2 + x * y % 3 == 0,
                    (x * y % 2 + x * y % 3) % 2 == 0, ((x + y) % 2 + x * y % 3) % 2 == 0,
                ][mask]
                if m and not is_fn[y][x]:
                    modules[y][x] = not modules[y][x]

    def penalty():
        score = 0
        lines = ["".join("1" if c else "0" for c in row) for row in modules]
        cols = ["".join("1" if modules[y][x] else "0" for y in range(size)) for x in range(size)]
        for line in lines + cols:
            run = 1
            for k in range(1, size):
                if line[k] == line[k - 1]:
                    run += 1
                else:
                    if run >= 5:
                        score += 3 + run - 5
                    run = 1
            if run >= 5:
                score += 3 + run - 5
            score += 40 * (line.count("10111010000") + line.count("00001011101"))
        for y in range(size - 1):
            for x in range(size - 1):
                if modules[y][x] == modules[y][x + 1] == modules[y + 1][x] == modules[y + 1][x + 1]:
                    score += 3
        dark = sum(c for row in modules for c in row)
        k = -(-abs(dark * 20 - size * size * 10) // (size * size)) - 1
        return score + 10 * max(k, 0)

    best_mask, best_score = 0, None
    for m in range(8):
        apply_mask(m); draw_format(m)
        s = penalty()
        if best_score is None or s < best_score:
            best_mask, best_score = m, s
        apply_mask(m)  # undo
    apply_mask(best_mask)
    draw_format(best_mask)
    return modules


def qr_svg(text, border=4, dark="#14283B", light="#FFFFFF"):
    """QR code as a standalone SVG string (scales to any size)."""
    m = make_matrix(text)
    n = len(m)
    parts = []
    for y, row in enumerate(m):
        x = 0
        while x < n:
            if row[x]:
                start = x
                while x < n and row[x]:
                    x += 1
                parts.append(f"M{start + border},{y + border}h{x - start}v1h-{x - start}z")
            else:
                x += 1
    total = n + 2 * border
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {total} {total}" '
            f'shape-rendering="crispEdges"><rect width="{total}" height="{total}" fill="{light}"/>'
            f'<path d="{"".join(parts)}" fill="{dark}"/></svg>')
